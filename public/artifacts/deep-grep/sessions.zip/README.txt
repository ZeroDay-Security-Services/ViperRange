One session log carries an extra line. Everything else is noise.
